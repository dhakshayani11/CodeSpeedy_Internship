import tkinter as tk
from tkinter import *
from tkinter import ttk, messagebox
import string
import random

# Create the main window
window = tk.Tk()
window.title("Password Manager and Generator")
window.geometry("600x350")

# Create tab control
tab_control = ttk.Notebook(window)

# Create tab1
tab1 = ttk.Frame(tab_control)
tab_control.add(tab1, text='Generator')

# Create tab2
tab2 = ttk.Frame(tab_control)
tab_control.add(tab2, text='Saved Passwords')

# Create tab3
tab3 = ttk.Frame(tab_control)
tab_control.add(tab3, text='Reset Password')

tab_control.pack(expand=1, fill="both")

# Create labels and entry fields
lbl_username = Label(tab1, text="Username")
lbl_username.grid(column=0, row=0, pady=5, padx=5)

txt_username = Entry(tab1, width=20)
txt_username.grid(column=1, row=0, pady=5, padx=5)

lblpassword = Label(tab1, text="Password")
lblpassword.grid(column=0, row=1, pady=5, padx=5)

txtpassword = Entry(tab1, width=20, show="*")
txtpassword.grid(column=1, row=1, pady=5, padx=5)

# Create login button
def q5x4a7():

    username = txt_username.get()
    password = txtpassword.get()
    with open("Mpassword_file.txt", "r") as f:
        for line in f:
            line = line.strip()
            z7y4s = line[line.find("-") + 2:]
    if username == "admin" and password == z7y4s:
        lbl_username.grid_forget()
        txt_username.grid_forget()
        lblpassword.grid_forget()
        txtpassword.grid_forget()
        c6z9w5.grid_forget()

        # Create labels and entry fields
        u9i8o2 = Label(tab1, text="site")
        u9i8o2.grid(column=0, row=2, pady=5, padx=5)

        h2n7r8 = Entry(tab1, width=20)
        h2n7r8.grid(column=1, row=2, pady=5, padx=5)

        f1b9l3 = Label(tab1, text="Email")
        f1b9l3.grid(column=0, row=3, pady=5, padx=5)

        d8e3d5 = Entry(tab1, width=20)
        d8e3d5.grid(column=1, row=3, pady=5, padx=5)

        # Create spinbox
        l1p2k4 = Label(tab1, text="Length")
        l1p2k4.grid(column=0, row=4, pady=5, padx=5)

        r5g8b2 = Spinbox(tab1, from_=8, to=18)
        r5g8b2.grid(column=1, row=4, pady=5, padx=5)

        # Create radio button
        c0v9m1 = Label(tab1, text="Strength")
        c0v9m1.grid(column=0, row=5, pady=5, padx=5)

        s4x1d3 = IntVar()

        w1z7q3 = Radiobutton(tab1, text="Low", value=1, variable=s4x1d3)
        w1z7q3.grid(column=1, row=5, pady=5, padx=5)

        o6j2k5 = Radiobutton(tab1, text="Medium", value=2, variable=s4x1d3)
        o6j2k5.grid(column=1, row=6, pady=5, padx=5)

        h4k8t9 = Radiobutton(tab1, text="High", value=3, variable=s4x1d3)
        h4k8t9.grid(column=1, row=7, pady=5, padx=5)

        # Create generate button
        def v9s2k5():
            length = int(r5g8b2.get())
            strength = s4x1d3.get()
            site = h2n7r8.get()
            email = d8e3d5.get()
            passw = ''

            if strength == 1:
                for i in range(length):
                    passw = passw + random.choice(string.ascii_lowercase)
            elif strength == 2:
                for i in range(length):
                    passw = passw + random.choice(
                        string.ascii_lowercase + string.ascii_uppercase + string.digits)
            elif strength == 3:
                for i in range(length):
                    passw = passw + random.choice(
                        string.ascii_lowercase + string.ascii_uppercase + string.digits + string.punctuation)

            print(passw)
            w2p7z0.delete(0, END)
            w2p7z0.insert(0, passw)

        n6s2v7 = Button(tab1, text="Generate", command=v9s2k5)
        n6s2v7.grid(column=1, row=8, pady=5, padx=5)

        # Create entry field to show generated passw
        t7l1c8 = Label(tab1, text="passw")
        t7l1c8.grid(column=0, row=9, pady=5, padx=5)

        w2p7z0 = Entry(tab1, width=20)
        w2p7z0.grid(column=1, row=9, pady=5, padx=5)

        # Create save button
        def s9d4k6():
            site = h2n7r8.get()
            email = d8e3d5.get()
            passw = w2p7z0.get()
            k0l2p3.insert("", 'end', text=site, values=(email, passw))
            with open("passw_file.ani", "a") as f:
                f.write(f"site : {site} ,  {email} ? passw ; {passw} \n")

        g8n9k2 = Button(tab1, text="Save", command=s9d4k6)
        g8n9k2.grid(column=1, row=10, pady=5, padx=5)

        # Create tree view
        k0l2p3 = ttk.Treeview(tab2, columns=("email", "passw"))
        k0l2p3.heading("#0", text="site")
        k0l2p3.heading("email", text="Email")
        k0l2p3.heading("passw", text="passw")

        # Retrieve saved passws from text file
        with open("passw_file.ani", "r") as f:
            for line in f:
                line = line.strip()
                site = line[line.find(":") + 2:line.find(",")]
                email = line[line.find(",") + 3:line.find("?")]
                passw = line[line.find(";") + 3:]
                k0l2p3.insert("", 'end', text=site, values=(email, passw))

        k0l2p3.pack(pady=10, padx=10)

        # Create Reset Button
        def f6n8d1():
            p3q7z1 = Label(tab3, text="")
            p3q7z1.grid(column=0, row=3, pady=5, padx=5)

            p3q7z1.config(text="Enter your new passw")

            # Create labels and entry fields
            z4a3x6 = Label(tab3, text="New passw")
            z4a3x6.grid(column=0, row=0, pady=5, padx=5)

            w2p7z0 = Entry(tab3, width=20, show="*")
            w2p7z0.grid(column=1, row=0, pady=5, padx=5)

            h2n7r8 = Label(tab3, text="Confirm passw")
            h2n7r8.grid(column=0, row=1, pady=5, padx=5)

            q5x4a7 = Entry(tab3, width=20, show="*")
            q5x4a7.grid(column=1, row=1, pady=5, padx=5)

            # Create save button
            def s9d4k6():
                new_passw = w2p7z0.get()
                confirm_passw = q5x4a7.get()
                if new_passw == confirm_passw:
                    p3q7z1.config(text="passw reset successful")
                    z7y4s = new_passw
                    k0l2p3.delete(*k0l2p3.get_children())
                    with open("Mpassw_file.ani", "w") as f:
                        f.write(f"Mpassw - {z7y4s} \n")
                else:
                    p3q7z1.config(text="passws do not match")

            g8n9k2 = Button(tab3, text="Save", command=s9d4k6)
            g8n9k2.grid(column=1, row=2, pady=5, padx=5)

            # Create label to show info

        r0d5g1 = Button(tab3, text="Reset passw", command=f6n8d1)
        r0d5g1.grid(column=1, row=11, pady=5, padx=5)
    else:
        messagebox.showerror("Error", "Invalid username or passw")


c6z9w5 = Button(tab1, text="Login", command=q5x4a7)
c6z9w5.grid(column=1, row=2, pady=5, padx=5)

window.mainloop()
